#include<stdio.h>
int main(){
    char a,b;
    scanf("%c",&a);
    b = a + 'A' - 'a';
    printf("%c",b);
    return 0;
}