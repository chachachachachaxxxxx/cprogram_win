<div><font size='70'><center><b>第二次实验报告</b></center></font></div>

## Description

![](Grequest.png)

## Request1

![image-20211017113544840](request1.png)

### Solution

先设计一个文字预处理程序，将双城记中的单词剥离出来，导出到words.txt文件



### Code

## Request2

![](request2.png)

![](img2request2.png)

### Solution

### Code

## Request3

![](request3.png)

### Solution

### Code

## Request4

![](request4.png)

### Solution

### Code



