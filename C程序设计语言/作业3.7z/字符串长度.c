#include<stdio.h>
#include<string.h>
int main()
{
    printf("%d\n",strlen("hello,world\n"));
    printf("%d",sizeof("hello,world\n"));
    return 0;
}
