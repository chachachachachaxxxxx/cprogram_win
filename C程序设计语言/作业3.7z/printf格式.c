#include<stdio.h>
int main()
{
    char a,b;
    a = 'A';
    b = 'a';
    printf("%c %c\n",a,b);
    printf("%d %d\n",a,b);
    printf("%o %o\n",a,b);
    printf("%x %x\n",a,b);
    return 0;
}